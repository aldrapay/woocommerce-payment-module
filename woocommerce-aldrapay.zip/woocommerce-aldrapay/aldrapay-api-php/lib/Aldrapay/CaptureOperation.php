<?php
namespace Aldrapay;

class CaptureOperation extends ChildTransaction {
}
?>
