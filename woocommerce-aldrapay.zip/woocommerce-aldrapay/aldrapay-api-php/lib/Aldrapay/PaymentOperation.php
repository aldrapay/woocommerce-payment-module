<?php
namespace Aldrapay;

class PaymentOperation extends AuthorizationOperation {
}
?>
